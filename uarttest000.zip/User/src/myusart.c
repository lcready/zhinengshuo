#include "debug.h"
#include "myusart.h"
#include "as608.h"
#include <rtthread.h>

/*************************************************************
 * name:        usart_send
 * function:    通过串口发送指定数据
 * input:       USARTx - 指定USART或UART端口
 *              send_data - 待发送的数据
 *              data_num - 发送数据的个数
 * return:      无
 *************************************************************/
void usart_send(USART_TypeDef *USARTx, u8 send_data[], int data_num)
{
    for (int i = 0; i < data_num; i++)
    {
        while (USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET)
            ;
        USART_SendData(USARTx, send_data[i]);
    }
}
