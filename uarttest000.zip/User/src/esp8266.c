#include "esp8266.h"
#include <rtthread.h>
#include <rthw.h>
#include "debug.h"
#include "mg90s.h"
#include "as608.h"

int connect_flag = 0;   //连接成功与否指示
char recbuf[128] = {0}; //数据接收buf
int cnt = 0;            //指示接收数据长度
int connect_scan_flag = 0;
int rec_flag = 0;

extern rt_sem_t sem_esprec;
extern rt_sem_t sem_sc2st;
extern rt_sem_t sem_keych;
extern char key_data[7];

/*************************************************************
 * name:        esp8266_init
 * function:    esp8266相关初始化，PC0(TX) PC1(RX) UART6 PC2使能信号输出
 * input:       add - 连接的服务器ip
 *              add_size - add数组长度
 *              port - 连接的服务器端口
 *              port_size - port数组长度
 * return:      无
 *************************************************************/
void esp8266_init(char add[], int add_size, char port[], int port_size)
{
    rt_kprintf("esp8266 init...\n");
    int i = 0;

    char cmd_connect[64] = "AT+CIPSTART=\"TCP\",\"";
    // GPIO、UART时钟使能
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART6, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

    // GPIO初始化
    GPIO_InitTypeDef g;
    g.GPIO_Mode = GPIO_Mode_AF_PP;
    g.GPIO_Pin = GPIO_Pin_0;
    g.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &g);
    g.GPIO_Mode = GPIO_Mode_IPU;
    g.GPIO_Pin = GPIO_Pin_1;
    GPIO_Init(GPIOC, &g);
    g.GPIO_Mode = GPIO_Mode_Out_PP;
    g.GPIO_Pin = GPIO_Pin_2;
    GPIO_Init(GPIOC, &g);
    GPIO_SetBits(GPIOC, GPIO_Pin_2);

    // uart初始化
    USART_InitTypeDef u;
    u.USART_BaudRate = 115200;
    u.USART_WordLength = USART_WordLength_8b;
    u.USART_StopBits = USART_StopBits_1;
    u.USART_Parity = USART_Parity_No;
    u.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    u.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(UART6, &u);
    USART_Cmd(UART6, ENABLE);
    rt_thread_mdelay(10000);
    //开启串口接收中断
    USART_ITConfig(UART6, USART_IT_RXNE, ENABLE);

    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = UART6_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    rt_kprintf("esp8266 init finished...\n");

    //组合连接命令
    rt_kprintf("connecting to server...\n");
    int tmp = 0;
    for (i = 0; i < add_size; i++)
    {
        while (cmd_connect[tmp] != '\0')
        {
            tmp++;
        }
        cmd_connect[tmp] = add[i];
        tmp++;
    }
    cmd_connect[tmp++] = '\"';
    cmd_connect[tmp++] = ',';
    for (i = 0; i < port_size; i++)
    {
        cmd_connect[tmp++] = port[i];
    }
    cmd_connect[tmp++] = '\r';
    cmd_connect[tmp++] = '\n';
    cmd_connect[tmp] = '\0';

    //发送连接命令
    int cmd_size = rt_strlen(cmd_connect);
    for (i = 0; i < cmd_size; i++)
    {
        while (USART_GetFlagStatus(UART6, USART_FLAG_TXE) == RESET)
            ;
        USART_SendData(UART6, cmd_connect[i]);
    }
}

//串口中断服务程序
void UART6_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void UART6_IRQHandler(void)
{
    while (USART_GetFlagStatus(UART6, USART_FLAG_RXNE) == RESET)
        ;
    if(cnt < 128)
    {
        recbuf[cnt++] = USART_ReceiveData(UART6);
    }
    connect_scan_flag = 0;
    rec_flag = 1;
}

/*************************************************************
 * name:        thread_connectrecscan_func
 * function:    esp8266接收扫描线程
 * input:       parameter - 线程创建时传递的参数
 * return:      无
 *************************************************************/
void thread_connectrecscan_func(void *parameter)
{
    while (1)
    {
        if (rec_flag == 1)
        {
            connect_scan_flag = 1;
            rt_thread_mdelay(2000);
            if (connect_scan_flag == 1)
            {
                rt_kprintf("release sem_esprec...\n");
                rt_sem_release(sem_esprec);
            }
        }
        rt_thread_mdelay(1000);
    }
}

/*************************************************************
 * name:        thread_connectdatadeal_func
 * function:    esp8266接收数据处理线程
 * input:       parameter - 线程创建时传递的参数
 * return:      无
 *************************************************************/
void thread_connectdatadeal_func(void *parameter)
{
    while (1)
    {
        rt_kprintf("connectrecdeal start...\n");
        rt_sem_take(sem_esprec, RT_WAITING_FOREVER);
        rt_kprintf("sem_esprec take...\n");
        int i = 0;
        if (recbuf[0] == '\r' && recbuf[1] == '\n' && recbuf[2] == '+' && recbuf[3] == 'I' && recbuf[4] == 'P' && recbuf[5] == 'D' && recbuf[6] == ',')
        {
            //判断为接收了数据
            i = 7;
            char tmp[8] = {0};
            char data[64] = {0};
            int n = 0, j = 0, sum = 0;
            //解析数据长度
            while (recbuf[i] != ':')
            {
                tmp[i - 7] = recbuf[i];
                i++;
                n++;
            }
            for (j = 0; j < n; j++)
            {
                sum = sum * 10 + (int)tmp[j] - 48;
            }

            //接收数据
            i++;
            for (j = 0; j < sum; j++)
            {
                data[j] = recbuf[i];
                i++;
            }
            data[j] = '\0'; //结尾加上\0方便比较
            rt_kprintf("%s\n", data);
            //对比命令
            if (rt_strcmp(data, "open door") == 0)
            {
                mg90s_ctrl(OPEN_DOOR);
                esp8266_send("door:1 ", rt_strlen("door:1 "));
            }
            else if (rt_strcmp(data, "close door") == 0)
            {
                mg90s_ctrl(CLOSE_DOOR);
                esp8266_send("door:0 ", rt_strlen("door:0 "));
            }
            else if (rt_strcmp(data, "connected") == 0)
            {
                rt_kprintf("connected to the server!\n");
            }
            else if (rt_strcmp(data, "clear all fingerprints") == 0)
            {
                if (as608_deleteall() == 0)
                {
                    rt_kprintf("all fingerprints has been deleted!\n");
                }
                else
                {
                    rt_kprintf("can't delete...\n");
                }
            }
            else if (rt_strcmp(data, "record fingerprint") == 0)
            {
                rt_sem_release(sem_sc2st);
            }
            else if (rt_strcmp(data, "door:1 ") == 0)
            {
                mg90s_ctrl(OPEN_DOOR);
            }
            else if (rt_strcmp(data, "door:0 ") == 0)
            {
                mg90s_ctrl(CLOSE_DOOR);
            }
            else if (rt_strcmp(data, "change password") == 0)
            {
                rt_kprintf("release sem_keych...\n");
                rt_sem_release(sem_keych);
            }
            else if (data[0] == 'p' && data[1] == 'a' && data[2] == 's' && data[3] == 's' && data[4] == 'w' && data[5] == 'o' && data[6] == 'r' && data[7] == 'd')
            {
                for (i = 0; i < 6; i++)
                {
                    key_data[i] = data[i + 9];
                }
                key_data[7] = 0;
            }
        }
        else
        {
            //rt_kprintf("%s\n", recbuf);
        }
        rec_flag = 0;
        cnt = 0;
        for (i = 0; i < 128; i++)
        {
            recbuf[i] = 0;
        }
    }
}

/*************************************************************
 * name:        esp8266_send
 * function:    esp8266发送函数，通过esp8266发送信息给服务器
 * input:       data - 字符型指针，指向发送的数据数组
 *              data_size - 发送数据长度
 * return:      无
 *************************************************************/
void esp8266_send(char *data, int data_size)
{
    char cmd_send[32] = "AT+CIPSEND=";
    char num[8] = {0};
    int tmp = data_size;
    int i = 0;
    rt_kprintf("sending...\n");
    if (data_size <= 0)
    {
        rt_kprintf("can't send <=0 data...\n");
        return;
    }
    while (tmp != 0)
    {
        num[i] = (tmp % 10) + 48; //解析data_size转换成ascii
        tmp /= 10;
        i++;
    }
    tmp = i - 1; //定位最高位

    //组包
    i = 11;
    for (; tmp >= 0; tmp--)
    {
        cmd_send[i++] = num[tmp];
    }
    cmd_send[i++] = '\r';
    cmd_send[i++] = '\n';
    cmd_send[i] = '\0';
    int sum = rt_strlen(cmd_send);
    for (i = 0; i < sum; i++)
    {
        while (USART_GetFlagStatus(UART6, USART_FLAG_TXE) == RESET)
            ;
        USART_SendData(UART6, cmd_send[i]);
    }
    //rt_kprintf("%s\n", cmd_send);
    rt_thread_mdelay(10);
    //发送数据
    for (i = 0; i < data_size; i++)
    {
        while (USART_GetFlagStatus(UART6, USART_FLAG_TXE) == RESET)
            ;
        USART_SendData(UART6, data[i]);
    }

    rt_kprintf("send finished!\n");
}
