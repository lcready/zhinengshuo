#include "debug.h"
#include "as608.h"
#include "myusart.h"
#include <rtthread.h>
#include <rthw.h>
#include "led.h"
#include "mg90s.h"
#include "esp8266.h"
#include "drivers/pin.h"

u8 cmd_packagehead[6] = {0xef, 0x01, 0xff, 0xff, 0xff, 0xff};                           //发送数据包头
u8 cmd_handshake[10] = {0x01, 0x00, 0x07, 0x13, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1b};    //握手口令，应答包12字节
u8 cmd_readmodenum[6] = {0x01, 0x00, 0x03, 0x1d, 0x00, 0x21};                           //读当前存储的模板个数，应答包14字节
u8 cmd_getimage[6] = {0x01, 0x00, 0x03, 0x01, 0x00, 0x05};                              //采集原始手指图像，应答包12字节
u8 cmd_genfeature1[7] = {0x01, 0x00, 0x04, 0x02, 0x01, 0x00, 0x08};                     //从图像生成特征并存入CharBuffer1，应答包12字节
u8 cmd_genfeature2[7] = {0x01, 0x00, 0x04, 0x02, 0x02, 0x00, 0x09};                     //从图像生成特征并存入CharBuffer2，应答包12字节
u8 cmd_commode[6] = {0x01, 0x00, 0x03, 0x05, 0x00, 0x09};                               //通过CharBuffer1 2 中的特征生成模板，应答包12字节
u8 cmd_storedata[9] = {0x01, 0x00, 0x06, 0x06, 0x01, 0x00, 0x00, 0x00, 0x00};           //存储模板至指定位置，应答包12字节
u8 cmd_search[11] = {0x01, 0x00, 0x08, 0x04, 0x01, 0x00, 0x00, 0x03, 0xe7, 0x00, 0xf8}; //通过CharBuffer1中的特征搜索匹配指纹，应答包16字节
u8 cmd_readfingerprint[9] = {0x01, 0x00, 0x06, 0x07, 0x01, 0x00, 0x00, 0x00, 0x00};     //从flash中读取指定id号的指纹模板数据存入CharBuffer1，应答包12字节
u8 cmd_deletemode[10] = {0x01, 0x00, 0x07, 0x0c, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00};   //删除指定id号的指纹模板，[4][5]是pageId，[8][9]为校验和,应答包12字节
u8 cmd_deleteall[6] = {0x01, 0x00, 0x03, 0x0d, 0x00, 0x11};                             //删除所有指纹模板，应答包12字节
u8 cmd_readmode[9] = {0x01, 0x00, 0x06, 0x07, 0x01, 0x00, 0x00, 0x00, 0x00};            //读出指定pageId的模板到buf1，最后四位分别为页码与校验和，应答包12字节
u8 rec_buf[32] = {0};                                                                   //接收buf

int fingerprint_num = 0;
int count = 0, num = 0, c = 0;

extern rt_thread_t finger_scan;

extern rt_sem_t sem_sc2st;

/*************************************************************
 * name:        as608_init
 * function:    初始化as608指纹模块对应串口，使用uart4 PC10(TX)
 *              PC11(RX)，初始化按键按下检测输入接口PC9
 * input:       无
 * return:      成功返回0，失败返回-1
 *************************************************************/
int as608_init()
{
    rt_kprintf("as608 init...\n");
    // GPIO、UART时钟使能
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

    // GPIO端口初始化
    GPIO_InitTypeDef g;
    g.GPIO_Mode = GPIO_Mode_AF_PP;
    g.GPIO_Pin = GPIO_Pin_10;
    g.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &g);
    g.GPIO_Mode = GPIO_Mode_IPU;
    g.GPIO_Pin = GPIO_Pin_11;
    GPIO_Init(GPIOC, &g);
    g.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    g.GPIO_Pin = GPIO_Pin_9;
    GPIO_Init(GPIOC, &g);

    // uart初始化
    USART_InitTypeDef u;
    u.USART_BaudRate = 57600;
    u.USART_WordLength = USART_WordLength_8b;
    u.USART_StopBits = USART_StopBits_1;
    u.USART_Parity = USART_Parity_No;
    u.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    u.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(UART4, &u);

    USART_Cmd(UART4, ENABLE);
    USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);

    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    //设备握手
    int cnt = 0;
    for (cnt = 0; cnt < 10; cnt++)
    {
        count = 0;
        num = 12;
        usart_send(UART4, cmd_packagehead, sizeof(cmd_packagehead));
        usart_send(UART4, cmd_handshake, sizeof(cmd_handshake));
        while (count != num)
        {
            rt_thread_mdelay(100);
        }
        if (rec_buf[9] == 0x00)
        {
            break;
        }
    }

    //读模板个数，修正录入指纹变量
    while (1)
    {
        count = 0;
        num = 14;
        usart_send(UART4, cmd_packagehead, sizeof(cmd_packagehead));
        usart_send(UART4, cmd_readmodenum, sizeof(cmd_readmodenum));
        while (count != num)
        {
            rt_thread_mdelay(100);
        }
        if (rec_buf[9] == 0x00)
        {
            int tmp = 0;
            tmp = (int)((int)rec_buf[11] | (((int)rec_buf[10]) << 8));
            fingerprint_num += tmp;
            rt_kprintf("fingers_num = %d\n", fingerprint_num);
            return 0;
        }
        continue;
    }
    return -1;
}

void UART4_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void UART4_IRQHandler(void)
{
    if (USART_GetFlagStatus(UART4, USART_FLAG_RXNE) == SET)
        rec_buf[count++] = USART_ReceiveData(UART4);
}

/*************************************************************
 * name:        as608_FingerImageGet
 * function:    录入指纹原始图像
 * input:       无
 * return:      无
 *************************************************************/
void as608_FingerImageGet()
{
    while (1)
    {
        while (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_9) != 1) //判断是否有手指按上，有手指按上跳出循环继续执行
            ;
        count = 0;
        num = 12;
        usart_send(UART4, cmd_packagehead, sizeof(cmd_packagehead)); //发送包头
        usart_send(UART4, cmd_getimage, sizeof(cmd_getimage));       //发送命令
        while (count != num)
        {
            rt_thread_mdelay(100);
        }
        if (rec_buf[9] != 0x00) //判断应答包确认码是否成功采集
        {
            continue;
        }
        break;
    }
}

/*************************************************************
 * name:        as608_GetFeature
 * function:    将指纹图像提取特征存于对应buf
 * input:       buf_num - buf号码，1或2
 * return:      成功返回0，失败返回对应错码
 *************************************************************/
int as608_GetFeature(int buf_num)
{
    while (1)
    {
        count = 0;
        num = 12;
        usart_send(UART4, cmd_packagehead, sizeof(cmd_packagehead)); //发送包头
        if (buf_num == 1)
        {
            usart_send(UART4, cmd_genfeature1, sizeof(cmd_genfeature1)); //发送命令
        }
        else if (buf_num == 2)
        {
            usart_send(UART4, cmd_genfeature2, sizeof(cmd_genfeature2)); //发送命令
        }
        else
        {
            return -1;
        }
        while (count != num)
        {
            rt_thread_mdelay(100);
        }
        if (rec_buf[9] == 0x00)
        {
            return 0;
        }
        else
        {
            return (int)rec_buf[9];
        }
    }
}

/*************************************************************
 * name:        as608_FingerprintStore
 * function:    存储指纹特征模板
 * input:       无
 * return:      成功返回0，失败返回对应错码
 *************************************************************/
int as608_FingerprintStore()
{
    while (1)
    {
        u8 tmp[4] = {0};
        int t_num = fingerprint_num;

        //判断存储位置是否有模板，修正位置
        while (1)
        {
            u8 t_tmp[4] = {0};
            t_tmp[0] = t_tmp[0] | (u8)(t_num >> 8);
            t_tmp[1] = t_tmp[1] | (u8)t_num;
            int s = 0;
            s = 0x01 + 0x06 + 0x07 + 0x01 + (int)t_tmp[0] + (int)t_tmp[1];
            t_tmp[2] = 0x00 | (u8)(s >> 8);
            t_tmp[3] = 0x00 | (u8)s;

            for (int i = 0; i < 4; i++)
            {
                cmd_readfingerprint[5 + i] = t_tmp[i];
            }
            count = 0;
            num = 12;
            usart_send(UART4, cmd_packagehead, sizeof(cmd_packagehead));         //发送包头
            usart_send(UART4, cmd_readfingerprint, sizeof(cmd_readfingerprint)); //发送命令
            while (count != num)
            {
                rt_thread_mdelay(100);
            }
            if (rec_buf[9] == 0x00) //成功读出代表里面有模板
            {
                t_num++;
                if (t_num == 1000)
                {
                    t_num = 0;
                }
                if (t_num == fingerprint_num) //扫描完全部存储位置仍未找到空位
                {
                    return -RT_ENOMEM;
                }
            }
            else if (rec_buf[9] == 0x0c) //无法读出代表内部无模板
            {
                fingerprint_num = t_num;
                break;
            }
            else
            {
                return -1;
            }
        }

        //计算位置号
        tmp[0] = tmp[0] | (u8)(fingerprint_num >> 8);
        tmp[1] = tmp[1] | (u8)fingerprint_num;

        //计算校验和
        int sum = 0;
        sum = 0x01 + 0x06 * 2 + 0x01 + (int)tmp[0] + (int)tmp[1];
        tmp[2] = tmp[2] | (u8)(sum >> 8);
        tmp[3] = tmp[3] | (u8)sum;

        //修改发送命令包
        int i = 0;
        for (i = 0; i < 4; i++)
        {
            cmd_storedata[5 + i] &= 0x00;   //清零最后四字节
            cmd_storedata[5 + i] |= tmp[i]; //修改
        }
        count = 0;
        num = 12;
        usart_send(UART4, cmd_packagehead, sizeof(cmd_packagehead)); //发送包头
        usart_send(UART4, cmd_storedata, sizeof(cmd_storedata));     //发送命令
        while (count != num)
        {
            rt_thread_mdelay(100);
        }
        if (rec_buf[9] == 0x00) //存储完成返回0，修正指纹序号
        {
            fingerprint_num++;
            if (fingerprint_num == 1000)
            {
                fingerprint_num = 0;
            }
            return 0;
        }
        else if (rec_buf[9] == 0x01)
        {
            continue;
        }
        else
        {
            return (int)rec_buf[9];
        }
    }
}

/*************************************************************
 * name:        as608_FingerprintEntry
 * function:    录入指纹
 * input:       无
 * return:      成功返回0，失败返回对应错码
 *************************************************************/
int as608_FingerprintEntry()
{
    //第一次采集指纹特征
    while (1)
    {
        //录入图像
        rt_kprintf("please put your finger on it.[1]\n");
        as608_FingerImageGet();

        //生成特征存于CharBuffer1
        int ret = as608_GetFeature(1);
        if (ret == 0)
        {
            break;
        }
        else if (ret == 0x01)
        {
            continue;
        }
        else
        {
            return ret;
        }
    }
    rt_kprintf("please release your finger.\n");
    while (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_9) == 1) //判断手指是否松开，松开跳出循环
        ;

    //第二次采集指纹特征
    while (1)
    {
        //录入图像
        rt_kprintf("please put your finger on it.[2]\n");
        as608_FingerImageGet();

        //生成特征存于CharBuffer2
        int ret = as608_GetFeature(2);
        if (ret == 0)
        {
            break;
        }
        else if (ret == 0x01)
        {
            continue;
        }
        else
        {
            return ret;
        }
    }

    //合并特征生成模板
    while (1)
    {
        count = 0;
        num = 12;
        usart_send(UART4, cmd_packagehead, sizeof(cmd_packagehead)); //发送包头
        usart_send(UART4, cmd_commode, sizeof(cmd_commode));         //发送命令
        while (count != num)
        {
            rt_thread_mdelay(100);
        }
        if (rec_buf[9] != 0x00)
        {
            if (rec_buf[9] == 0x0a)
            {
                return 0x0a;
            }
            continue;
        }
        break;
    }

    //存储模板
    while (1)
    {
        int ret = as608_FingerprintStore();
        return ret;
    }
}

/*************************************************************
 * name:        as608_FingerprintCheck
 * function:    匹配指纹
 * input:       无
 * return:      成功匹配返回0，失败返回对应错码，0x09表示未搜索到
 *************************************************************/
int as608_FingerprintCheck()
{
    //指纹图像采集
    while (1)
    {
        //录入图像
        as608_FingerImageGet();

        //生成特征存于CharBuffer1
        int ret = as608_GetFeature(1);
        if (ret == 0)
        {
            break;
        }
        else if (ret == 0x01)
        {
            continue;
        }
        else
        {
            return ret;
        }
    }

    //查找buf1中的特征匹配指纹
    while (1)
    {
        int cnt = 0;
        count = 0;
        num = 16;
        usart_send(UART4, cmd_packagehead, sizeof(cmd_packagehead)); //发送包头
        usart_send(UART4, cmd_search, sizeof(cmd_search));           //发送命令
        while (count != num)
        {
            rt_thread_mdelay(100);
        }
        if (rec_buf[9] == 0x00) //查找到返回0
        {
            return 0;
        }
        else if (rec_buf[9] == 0x09) //未查找到返回错码
        {
            return 0x09;
        }
        else
        {
            cnt++;
            if (cnt <= 10)
            {
                continue;
            }
            return 0x01;
        }
    }
}

/*************************************************************
 * name:        as608_deleteall
 * function:    删除所有as608指纹模板
 * input:       无
 * return:      成功返回0，失败返回-1
 *************************************************************/
int as608_deleteall()
{
    for (int i = 1; i < 10; i++)
    {
        count = 0;
        num = 12;
        usart_send(UART4, cmd_packagehead, sizeof(cmd_packagehead)); //发送包头
        usart_send(UART4, cmd_deleteall, sizeof(cmd_deleteall));     //发送命令
        while (count != num)
        {
            rt_thread_mdelay(100);
        }
        if (rec_buf[9] == 0x00)
        {
            return 0;
        }
    }
    return -1;
}

/*************************************************************
 * name:        as608_delete
 * function:    删除as608内指定的指纹模板
 * input:       num - 指纹模板序号（0-999）
 * return:      成功返回0，失败返回-1
 *************************************************************/
int as608_delete(int num)
{
    int tmp[4] = {0};

    //计算位置号
    tmp[0] = tmp[0] | (u8)(num >> 8);
    tmp[1] = tmp[1] | (u8)num;

    //计算校验和
    int sum = 0;
    sum = 0x01 + 0x07 + 0x0c + 0x01 + (int)tmp[0] + (int)tmp[1];
    tmp[2] = tmp[2] | (u8)(sum >> 8);
    tmp[3] = tmp[3] | (u8)sum;

    //修正命令
    cmd_deletemode[4] = tmp[0];
    cmd_deletemode[5] = tmp[1];
    cmd_deletemode[8] = tmp[2];
    cmd_deletemode[9] = tmp[3];

    count = 0;
    num = 12;
    usart_send(UART4, cmd_packagehead, sizeof(cmd_packagehead)); //发送包头
    usart_send(UART4, cmd_deletemode, sizeof(cmd_deletemode));   //发送命令
    while (count != num)
    {
        rt_thread_mdelay(100);
    }
    if (rec_buf[9] == 0x00)
    {
        return 0;
    }
    else
    {
        return -1;
    }
}

/*************************************************************
 * name:        thread_fingerscan_func
 * function:    手指扫描线程执行函数
 * input:       parameter - 线程创建时传递的参数
 * return:      无
 *************************************************************/
void thread_fingerscan_func(void *parameter)
{
    int num_touch = 0;
    while (1)
    {
        if (as608_FingerprintCheck() == 0)
        {
            num_touch = 0;
            rt_kprintf("fingerprint has been founded!\n");
            led_crtl(1, 0);
            rt_kprintf("open the door...\n");
            mg90s_ctrl(OPEN_DOOR);
            esp8266_send("door:1 ", rt_strlen("door:1 "));
            rt_thread_mdelay(1000);
            led_crtl(1, 1);
            rt_thread_mdelay(5000);
            rt_kprintf("close the door...\n");
            mg90s_ctrl(CLOSE_DOOR);
            esp8266_send("door:0 ", rt_strlen("door:0 "));
        }
        else
        {
            num_touch++;
            rt_kprintf("fingerprint is not been stored!\n");
            mg90s_ctrl(CLOSE_DOOR);
            esp8266_send("door:0 ", rt_strlen("door:0 "));
            led_crtl(2, 0);
            rt_thread_mdelay(1000);
            led_crtl(2, 1);
            if (num_touch == 10)
            {
                esp8266_send("warn:1\n", rt_strlen("warn:1\n"));
                num_touch = 0;
            }
        }
        rt_kprintf("please release your finger.\n");
        while (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_9) == 1) //判断手指是否松开，松开跳出循环
            ;
    }
}

/*************************************************************
 * name:        thread_fingerprintstore_func
 * function:    指纹录入线程执行函数
 * input:       parameter - 线程创建时传递的参数
 * return:      无
 *************************************************************/
void thread_fingerprintstore_func(void *parameter)
{
    while (1)
    {
        rt_kprintf("storethread start...\n");
        rt_sem_take(sem_sc2st, RT_WAITING_FOREVER);
        rt_thread_suspend(finger_scan);
        rt_kprintf("storing your finger...\n");
        if (as608_FingerprintEntry() == 0)
        {
            rt_kprintf("fingerprint has been stored!\n");
            led_crtl(1, 0);
            rt_thread_mdelay(1000);
            led_crtl(1, 1);
        }
        rt_thread_resume(finger_scan);
    }
}
