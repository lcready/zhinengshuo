#include "debug.h"
#include "led.h"

/*************************************************************
 * name:        led_init
 * function:    led相关gpio初始化
 * input:       无
 * return:      无
 *************************************************************/
void led_init()
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
    GPIO_InitTypeDef t;
    t.GPIO_Mode = GPIO_Mode_Out_PP;
    t.GPIO_Pin = LED1_Pin | LED2_Pin;
    t.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(LED_GPIO, &t);
    GPIO_WriteBit(LED_GPIO, LED1_Pin | LED2_Pin, LED_OFF);
}

/*************************************************************
 * name:        led_ctrl
 * function:    控制led的亮灭
 * input:       led_num - led序号（LED1/LED2）
 *              led_state - led状态（LED_ON/LED_OFF）
 * return:      无
 *************************************************************/
void led_crtl(int led_num, BitAction led_state)
{
    switch (led_num)
    {
    case 1:
        GPIO_WriteBit(LED_GPIO, LED1_Pin, led_state);
        break;
    case 2:
        GPIO_WriteBit(LED_GPIO, LED2_Pin, led_state);
        break;
    default:
        GPIO_WriteBit(LED_GPIO, LED1_Pin | LED2_Pin, LED_OFF);
        break;
    }
}