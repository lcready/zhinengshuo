#include "bluetooth.h"
#include <rtthread.h>
#include "debug.h"
#include <rthw.h>
#include "as608.h"
#include "mg90s.h"
#include "esp8266.h"

extern rt_sem_t sem_bthrec;
extern rt_sem_t sem_sc2st;
extern rt_sem_t sem_keych;

u8 blue_recbuf[3] = {0};

int flag = 0;

/*************************************************************
 * name:        bluetooth_init
 * function:    初始化蓝牙模块对应串口，PC12(TX) PD2(RX) UART5
 * input:       无
 * return:      无
 *************************************************************/
void bluetooth_init()
{
    rt_kprintf("bluetooth init...\n");
    // GPIO、UART时钟使能
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD, ENABLE);

    // GPIO端口初始化
    GPIO_InitTypeDef g;
    g.GPIO_Mode = GPIO_Mode_AF_PP;
    g.GPIO_Pin = GPIO_Pin_12;
    g.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &g);
    g.GPIO_Mode = GPIO_Mode_IPU;
    g.GPIO_Pin = GPIO_Pin_2;
    GPIO_Init(GPIOD, &g);

    // uart初始化
    USART_InitTypeDef u;
    u.USART_BaudRate = 9600;
    u.USART_WordLength = USART_WordLength_8b;
    u.USART_StopBits = USART_StopBits_1;
    u.USART_Parity = USART_Parity_No;
    u.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    u.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(UART5, &u);

    USART_ITConfig(UART5, USART_IT_RXNE, ENABLE);

    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(UART5, ENABLE);
    rt_kprintf("bluetooth init finished...\n");
}

//串口中断服务程序
void UART5_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void UART5_IRQHandler(void)
{
    // rt_kprintf("uart5irq...\n");
    static int i = 0;
    if (USART_GetITStatus(UART5, USART_IT_RXNE) == SET)
    {
        blue_recbuf[i++] = USART_ReceiveData(UART5);
        if (blue_recbuf[0] != 0xef)
        {
            i = 0;
        }
    }
    if (i == 3)
    {
        i = 0;
        flag = 1;
        rt_kprintf("flag has been set!\n");
    }
}

/*************************************************************
 * name:        thread_bluetoothscan_func
 * function:    蓝牙接收串口数据中断判定线程，若接收数据满3字节则
 *              唤醒处理线程
 * input:       parameter - 线程创建时传递的参数
 * return:      无
 *************************************************************/
void thread_bluetoothscan_func(void *parameter)
{
    while (1)
    {
        if (flag == 1)
        {
            rt_kprintf("%d,%d,%d\n", blue_recbuf[0], blue_recbuf[1], blue_recbuf[2]);
            flag = 0;
            rt_kprintf("sem_bthrec release\n");
            rt_sem_release(sem_bthrec);
        }
        rt_thread_mdelay(1000);
    }
}

/*************************************************************
 * name:        thread_bluetoothrec_func
 * function:    蓝牙接收中断处理线程
 * input:       parameter - 线程创建时传递的参数
 * return:      无
 *************************************************************/
void thread_bluetoothrec_func(void *parameter)
{
    u8 err[3] = {0xef, 0xee, 0x0a};
    while (1)
    {
        rt_kprintf("bluetoothrec_start\n");
        rt_sem_take(sem_bthrec, RT_WAITING_FOREVER);
        rt_kprintf("bluetoothrec take\n");
        if (blue_recbuf[0] != 0xef || blue_recbuf[2] != 0x0a)
        {
            rt_kprintf("NONE\n");
            continue;
        }
        else if (blue_recbuf[0] == 0xef && blue_recbuf[2] == 0x0a)
        {
            rt_kprintf("y\n");
            switch ((int)blue_recbuf[1])
            {
            case 0x01:
                rt_sem_release(sem_sc2st); // 0x01使能指纹录入线程
                break;
            case 0x02: //删除所有指纹模板
                if (as608_deleteall() == 0)
                {
                    rt_kprintf("fingerprints in as608 has been all deleted!\n");
                }
                else
                {
                    rt_kprintf("delete failed...\n");
                    for (int i = 0; i < 3; i++)
                    {
                        while (USART_GetFlagStatus(UART5, USART_FLAG_TXE) == RESET)
                            ;
                        USART_SendData(UART5, err[i]);
                    }
                }
                break;
            case 0x03:
                rt_kprintf("close the door...\n");
                mg90s_ctrl(CLOSE_DOOR);
                esp8266_send("door:0 ", rt_strlen("door:0 "));
                break;
            case 0x04:
                rt_kprintf("open the door...\n");
                mg90s_ctrl(OPEN_DOOR);
                esp8266_send("door:1 ", rt_strlen("door:1 "));
                break;
            case 0x05: //更改密码
                rt_kprintf("release sem_keych...\n");
                rt_sem_release(sem_keych);
                break;
            default:
                rt_kprintf("bluetooth command error...\n");
                for (int i = 0; i < 3; i++)
                {
                    while (USART_GetFlagStatus(UART5, USART_FLAG_TXE) == RESET)
                        ;
                    USART_SendData(UART5, err[i]);
                }
                break;
            }
        }
    }
}
