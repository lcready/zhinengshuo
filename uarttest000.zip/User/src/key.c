#include "key.h"
#include <rtthread.h>
#include <rthw.h>
#include "debug.h"
#include "drivers/pin.h"
#include <rtdef.h>
#include "mg90s.h"
#include "esp8266.h"
#include "led.h"

char key_data[7] = {'1', '2', '3', '4', '5', '6', '\0'}; //密码设置
char key_input[7] = {0};
int count_t = 0;

extern rt_thread_t key_scancheck;
extern rt_sem_t sem_keych;
extern rt_sem_t sem_keyscan;

/*************************************************************
 * name:        thread_keychange_func
 * function:    修改密码线程
 * input:       parameter - 线程创建时传递的参数
 * return:      无
 *************************************************************/
void thread_keychange_func(void *parameter)
{
    while (1)
    {
        rt_kprintf("keychangesem taking...\n");
        rt_sem_take(sem_keych, RT_WAITING_FOREVER);
        rt_thread_suspend(key_scancheck);
        count_t = 0;
        char ch[7] = {0};
        char send_data[64] = {0};
        rt_kprintf("keychange start...\n");
        rt_strncpy(send_data, "password:", rt_strlen("password:"));
        while (count_t != 6)
        {
            rt_strncpy(ch, key_input, 6);
        }
        rt_strncpy(key_data, key_input, 6);
        for (int i = 0; i < 6; i++)
        {
            send_data[9 + i] = key_input[i];
        }
        esp8266_send(send_data, rt_strlen(send_data));
        rt_kprintf("password has been changed!\n");
        count_t = 0;
        rt_thread_resume(key_scancheck);
    }
}

/*************************************************************
 * name:        key1_init
 * function:    按键扫描gpio初始化，使用中断方式
 * input:       无
 * return:      无
 *************************************************************/
void key1_init()
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    EXTI_InitTypeDef EXTI_InitStructure = {0};
    NVIC_InitTypeDef NVIC_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOE, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    GPIO_ResetBits(GPIOE, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);

    /* GPIOA ----> EXTI_Line0 */
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource0);
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource1);
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource2);
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource3);
    EXTI_InitStructure.EXTI_Line = EXTI_Line0 | EXTI_Line1 | EXTI_Line2 | EXTI_Line3;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
    NVIC_Init(&NVIC_InitStructure);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
    NVIC_Init(&NVIC_InitStructure);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;
    NVIC_Init(&NVIC_InitStructure);
}

/*************************************************************
 * name:        exti_disable
 * function:    关按键扫描中断
 * input:       无
 * return:      无
 *************************************************************/
void exti_disable()
{
    EXTI_InitTypeDef EXTI_InitStructure = {0};
    EXTI_InitStructure.EXTI_Line = EXTI_Line0 | EXTI_Line1 | EXTI_Line2 | EXTI_Line3;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = DISABLE;
    EXTI_Init(&EXTI_InitStructure);
}

/*************************************************************
 * name:        exti_enable
 * function:    开按键扫描中断
 * input:       无
 * return:      无
 *************************************************************/
void exti_enable()
{
    EXTI_InitTypeDef EXTI_InitStructure = {0};
    EXTI_InitStructure.EXTI_Line = EXTI_Line0 | EXTI_Line1 | EXTI_Line2 | EXTI_Line3;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
}

/*************************************************************
 * name:        scan
 * function:    进中断后判断按键
 * input:       pin - 传送需要判断对应的列脚
 * return:      无
 *************************************************************/
int scan(uint16_t pin)
{
    GPIO_SetBits(GPIOE, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
    for (int i = 0; i < 4; i++)
    {
        switch (i)
        {
        case 0:
            GPIO_SetBits(GPIOE, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
            GPIO_ResetBits(GPIOE, GPIO_Pin_4);
            break;
        case 1:
            GPIO_SetBits(GPIOE, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
            GPIO_ResetBits(GPIOE, GPIO_Pin_5);
            break;
        case 2:
            GPIO_SetBits(GPIOE, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
            GPIO_ResetBits(GPIOE, GPIO_Pin_6);
            break;
        case 3:
            GPIO_SetBits(GPIOE, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
            GPIO_ResetBits(GPIOE, GPIO_Pin_7);
            break;
        }
        if (GPIO_ReadInputDataBit(GPIOE, pin) == 0)
        {
            while (GPIO_ReadInputDataBit(GPIOE, pin) == 0)
                ;
            GPIO_ResetBits(GPIOE, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
            return (i + 1);
        }
    }
    GPIO_ResetBits(GPIOE, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
    return 0;
}

//第一列有按键按下中断服务程序
void EXTI0_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void EXTI0_IRQHandler(void)
{
    rt_kprintf("ex0.");
    exti_disable();
    switch (scan(GPIO_Pin_0))
    {
    case 1:
        key_input[count_t++] = '1';
        break;
    case 2:
        key_input[count_t++] = '4';
        break;
    case 3:
        key_input[count_t++] = '7';
        break;
    case 4:
        key_input[count_t++] = '*';
        break;
    }
    rt_kprintf("%c\n", key_input[count_t - 1]);
    exti_enable();
    EXTI_ClearITPendingBit(EXTI_Line0);
}

//第二列有按键按下中断服务程序
void EXTI1_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void EXTI1_IRQHandler(void)
{
    rt_kprintf("ex1.");
    exti_disable();
    switch (scan(GPIO_Pin_1))
    {
    case 1:
        key_input[count_t++] = '2';
        break;
    case 2:
        key_input[count_t++] = '5';
        break;
    case 3:
        key_input[count_t++] = '8';
        break;
    case 4:
        key_input[count_t++] = '0';
        break;
    }
    rt_kprintf("%c\n", key_input[count_t - 1]);
    exti_enable();
    EXTI_ClearITPendingBit(EXTI_Line1);
}

//第三列有按键按下中断服务程序
void EXTI2_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void EXTI2_IRQHandler(void)
{
    rt_kprintf("ex2.");
    exti_disable();
    switch (scan(GPIO_Pin_2))
    {
    case 1:
        key_input[count_t++] = '3';
        break;
    case 2:
        key_input[count_t++] = '6';
        break;
    case 3:
        key_input[count_t++] = '9';
        break;
    case 4:
        key_input[count_t++] = '#';
        break;
    }
    rt_kprintf("%c\n", key_input[count_t - 1]);
    exti_enable();
    EXTI_ClearITPendingBit(EXTI_Line2);
}

//第四列有按键按下中断服务程序
void EXTI3_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void EXTI3_IRQHandler(void)
{
    rt_kprintf("ex3.");
    exti_disable();
    switch (scan(GPIO_Pin_3))
    {
    case 1:
        key_input[count_t++] = 'A';
        break;
    case 2:
        key_input[count_t++] = 'B';
        break;
    case 3:
        key_input[count_t++] = 'C';
        break;
    case 4:
        key_input[count_t++] = 'D';
        break;
    }
    rt_kprintf("%c\n", key_input[count_t - 1]);
    exti_enable();
    EXTI_ClearITPendingBit(EXTI_Line3);
}

/*************************************************************
 * name:        thread_keyscancheck_func
 * function:    按键扫描判定，确定按键密码数量足够则发送信号量唤醒
 *              密码判断线程
 * input:       parameter - 线程创建时传递的参数
 * return:      无
 *************************************************************/
void thread_keyscancheck_func(void *parameter)
{
    rt_kprintf("thread_keyscancheck_func entry...\n");
    while (1)
    {
        while (count_t != 6)
        {
            rt_thread_mdelay(1000);
        }
        count_t = 0;
        rt_kprintf("sem_keyscan release...\n");
        rt_sem_release(sem_keyscan);
    }
}

/*************************************************************
 * name:        thread_keyscan_func
 * function:    按键扫描密码处理线程
 * input:       parameter - 线程创建时传递的参数
 * return:      无
 *************************************************************/
void thread_keyscan_func(void *parameter)
{
    int num = 0;
    while (1)
    {
        rt_kprintf("sem_keyscan taking...\n");
        rt_sem_take(sem_keyscan, RT_WAITING_FOREVER);
        rt_kprintf("sem_keyscan toke...\n");
        if (rt_strcmp(key_input, key_data) == 0)
        {
            num = 0;
            rt_kprintf("password correct!\n");
            led_crtl(1, 0);
            rt_kprintf("open the door...\n");
            mg90s_ctrl(OPEN_DOOR);
            esp8266_send("door:1 ", rt_strlen("door:1 "));
            rt_thread_mdelay(1000);
            led_crtl(1, 1);
            rt_thread_mdelay(5000);
            rt_kprintf("close the door...\n");
            mg90s_ctrl(CLOSE_DOOR);
            esp8266_send("door:0 ", rt_strlen("door:0 "));
        }
        else
        {
            num++;
            rt_kprintf("fingerprint is not been stored!\n");
            mg90s_ctrl(CLOSE_DOOR);
            esp8266_send("door:0 ", rt_strlen("door:0 "));
            led_crtl(2, 0);
            rt_thread_mdelay(1000);
            led_crtl(2, 1);
            if (num == 10)
            {
                esp8266_send("warn:1\n", rt_strlen("warn:1\n"));
                num = 0;
            }
            rt_kprintf("password wrong...\n");
        }
    }
}
