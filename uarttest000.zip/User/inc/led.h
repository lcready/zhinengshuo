#ifndef __LED_H__
#define __LED_H__

#define LED_GPIO GPIOE
#define LED1_Pin GPIO_Pin_11
#define LED2_Pin GPIO_Pin_12
#define LED_ON 0
#define LED_OFF 1
#define LED1 1
#define LED2 2

/*************************************************************
 * name:        led_init
 * function:    led相关gpio初始化
 * input:       无
 * return:      无
 *************************************************************/
void led_init();

/*************************************************************
 * name:        led_ctrl
 * function:    控制led的亮灭
 * input:       led_num - led序号（LED1/LED2）
 *              led_state - led状态（LED_ON/LED_OFF）
 * return:      无
 *************************************************************/
void led_crtl(int led_num, BitAction led_state);

#endif