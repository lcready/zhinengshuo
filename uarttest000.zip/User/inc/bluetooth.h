#ifndef __BLUETOOTH_H__
#define __BLUETOOTH_H__

/*************************************************************
 * name:        bluetooth_init
 * function:    初始化蓝牙模块对应串口，PC12(TX) PD2(RX) UART5
 * input:       无
 * return:      无
 *************************************************************/
void bluetooth_init();

/*************************************************************
 * name:        thread_bluetoothrec_func
 * function:    蓝牙接收中断处理线程
 * input:       parameter - 线程创建时传递的参数
 * return:      无
 *************************************************************/
void thread_bluetoothrec_func(void *parameter);

/*************************************************************
 * name:        thread_bluetoothscan_func
 * function:    蓝牙接收串口数据中断判定线程，若接收数据满3字节则
 *              唤醒处理线程
 * input:       parameter - 线程创建时传递的参数
 * return:      无
 *************************************************************/
void thread_bluetoothscan_func(void *parameter);
#endif