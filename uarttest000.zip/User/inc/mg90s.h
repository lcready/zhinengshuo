#ifndef __MG90S_H__
#define __MG90S_H__

#define CLOSE_DOOR 0
#define OPEN_DOOR 2

/*************************************************************
 * name:        mg90s_init
 * function:    mg90s相关初始化
 * input:       arr - 重装值
 *              psc - 分频系数
 *              ccp - 比较计数值
 * return:      无
 *************************************************************/
void mg90s_init(u16 arr, u16 psc, u16 ccp);

/*************************************************************
 * name:        mg90s_ctrl
 * function:    mg90s设置转的角度
 * input:       ccp - 比较计数值，取值为
 *              0° - 195；45° - 190；90° - 185；
 *              135° - 180；180° - 175
 * return:      无
 *************************************************************/
void mg90s_ctrl(int ccp);

#endif
