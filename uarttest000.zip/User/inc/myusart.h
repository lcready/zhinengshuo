#ifndef __MYUSART_H__
#define __MYUSART_H__

#include "ch32v30x.h"

/*************************************************************
 * name:        usart_send
 * function:    通过串口发送指定数据
 * input:       USARTx - 指定USART或UART端口
 *              send_data - 待发送的数据
 *              data_num - 发送数据的个数
 * return:      无
 *************************************************************/
void usart_send(USART_TypeDef *USARTx, u8 send_data[], int data_num);


#endif