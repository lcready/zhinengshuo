#ifndef __ESP8266_H__
#define __ESP8266_H__

/*************************************************************
 * name:        esp8266_init
 * function:    esp8266相关初始化，PC0(TX) PC1(RX) UART6
 * input:       add - 连接的服务器ip
 *              add_size - add数组长度
 *              port - 连接的服务器端口
 *              port_size - port数组长度
 * return:      无
 *************************************************************/
void esp8266_init(char add[], int add_size, char port[], int port_size);

/*************************************************************
 * name:        esp8266_send
 * function:    esp8266发送函数，通过esp8266发送信息给服务器
 * input:       data - 字符型指针，指向发送的数据数组
 *              data_size - 发送数据长度
 * return:      无
 *************************************************************/
void esp8266_send(char *data, int data_size);

/*************************************************************
 * name:        thread_connectrecscan_func
 * function:    esp8266接收扫描线程
 * input:       parameter - 线程创建时传递的参数
 * return:      无
 *************************************************************/
void thread_connectrecscan_func(void *parameter);

/*************************************************************
 * name:        thread_connectdatadeal_func
 * function:    esp8266接收数据处理线程
 * input:       parameter - 线程创建时传递的参数
 * return:      无
 *************************************************************/
void thread_connectdatadeal_func(void *parameter);

#endif