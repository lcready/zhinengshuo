#include "ch32v30x.h"
#include <rtthread.h>
#include <rthw.h>
#include "led.h"
#include "as608.h"
#include <rtdbg.h>
#include "bluetooth.h"
#include "mg90s.h"
#include "esp8266.h"
#include "key.h"

rt_thread_t finger_scan = NULL;       //手指扫描线程
rt_thread_t fingerprint_store = NULL; //指纹录入线程
rt_thread_t bluetooth = NULL;         //蓝牙线程
rt_thread_t bluetooth_scan = NULL;    //蓝牙中断数据扫描判定线程
rt_thread_t esp_scan = NULL;          // esp8266扫描判定数据接收完成线程
rt_thread_t esp_rec = NULL;           // exp8266接收数据处理线程
rt_thread_t key_change = NULL;     //按键修改密码线程
rt_thread_t key_scan = NULL;
rt_thread_t key_scancheck = NULL;

rt_sem_t sem_sc2st = NULL;  //指纹录入信号量
rt_sem_t sem_bthrec = NULL; //蓝牙串口接收信号量
rt_sem_t sem_esprec = NULL; // esp8266接收数据处理信号量
rt_sem_t sem_keych = NULL; //按键扫描修改密码信号量
rt_sem_t sem_keyscan = NULL;

int main(void)
{
    rt_kprintf("main running....\n");
    rt_kprintf("device init...\n");
    key1_init();
    led_init();
    as608_init();
    bluetooth_init();
    esp8266_init("192.168.199.15", rt_strlen("192.168.199.15"), "45678", 5);
    mg90s_init(200 - 1, 14400 - 1, 195);
    rt_kprintf("device init finished...\n");

    finger_scan = rt_thread_create("finger_scan_thread", thread_fingerscan_func, NULL, 512, 10, 50);
    if (finger_scan == RT_NULL)
    {
        rt_kprintf("finger_scan_thread create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("finger_scan_thread created!\n");

    fingerprint_store = rt_thread_create("fingerprint_store_thread", thread_fingerprintstore_func, NULL, 512, 8, 5);
    if (fingerprint_store == RT_NULL)
    {
        rt_kprintf("fingerprint_store_thread create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("fingerprint_store_thread created!\n");

    bluetooth = rt_thread_create("bluetooth_thread", thread_bluetoothrec_func, NULL, 512, 8, 5);
    if (bluetooth == RT_NULL)
    {
        rt_kprintf("bluetooth_thread create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("bluetooth_thread created!\n");

    esp_rec = rt_thread_create("esprec_thread", thread_connectdatadeal_func, NULL, 512, 8, 5);
    if (esp_rec == RT_NULL)
    {
        rt_kprintf("esprec_thread create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("esprec_thread created!\n");

    key_change = rt_thread_create("key_change_thread", thread_keychange_func, NULL, 512, 7, 5);
    if (key_change == RT_NULL)
    {
        rt_kprintf("key_change_thread create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("key_change_thread created!\n");

    key_scan = rt_thread_create("key_scan_thread", thread_keyscan_func, NULL, 512, 8, 5);
    if (key_scan == RT_NULL)
    {
        rt_kprintf("key_scan_thread create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("key_scan_thread created!\n");

    bluetooth_scan = rt_thread_create("bluetoothscan_thread", thread_bluetoothscan_func, NULL, 256, 10, 50);
    if (bluetooth_scan == RT_NULL)
    {
        rt_kprintf("bluetoothscan_thread create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("bluetoothscan_thread created!\n");

    key_scancheck = rt_thread_create("key_scancheck_thread", thread_keyscancheck_func, NULL, 256, 10, 50);
    if (key_scancheck == RT_NULL)
    {
        rt_kprintf("key_scancheck_thread create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("key_scancheck_thread created!\n");

    esp_scan = rt_thread_create("espscan_thread", thread_connectrecscan_func, NULL, 256, 10, 50);
    if (esp_scan == RT_NULL)
    {
        rt_kprintf("espscan_thread create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("espscan_thread created!\n");
#if 0
    key_th1 = rt_thread_create("key", key_entry, RT_NULL, 256, 10, 10);
    if (key_th1 == RT_NULL)
    {
        rt_kprintf("key_thread_create fail..\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("key_thread_create succeed..\n");
#endif
    sem_sc2st = rt_sem_create("sem_sc2st", 0, RT_IPC_FLAG_FIFO);
    if (sem_sc2st == RT_NULL)
    {
        rt_kprintf("sem_sc2st create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("sem_sc2st created!\n");

    sem_bthrec = rt_sem_create("sem_bthrec", 0, RT_IPC_FLAG_FIFO);
    if (sem_bthrec == RT_NULL)
    {
        rt_kprintf("sem_bthrec create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("sem_bthrec created!\n");

    sem_esprec = rt_sem_create("sem_esprec", 0, RT_IPC_FLAG_FIFO);
    if (sem_esprec == RT_NULL)
    {
        rt_kprintf("sem_esprec create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("sem_esprec created!\n");

    sem_keyscan = rt_sem_create("sem_keyscan", 0, RT_IPC_FLAG_FIFO);
    if (sem_keyscan == RT_NULL)
    {
        rt_kprintf("sem_keyscan create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("sem_keyscan created!\n");

#if 1
    sem_keych = rt_sem_create("sem_keych", 0, RT_IPC_FLAG_FIFO);
    if (sem_keych == RT_NULL)
    {
        rt_kprintf("sem_keych create failed...\n");
        return -RT_ENOMEM;
    }
    rt_kprintf("sem_keych created!\n");
#endif
    rt_thread_startup(finger_scan);
    rt_thread_startup(fingerprint_store);
    rt_thread_startup(bluetooth);
    rt_thread_startup(bluetooth_scan);
    rt_thread_startup(esp_scan);
    rt_thread_startup(esp_rec);
    
    // rt_thread_startup(key_th1);
    rt_thread_startup(key_change);
    rt_thread_startup(key_scan);
    rt_thread_startup(key_scancheck);

    rt_kprintf("main over...\n");
    return 0;
}
